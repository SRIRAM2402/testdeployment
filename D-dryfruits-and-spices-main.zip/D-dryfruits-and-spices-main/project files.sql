create table ddryfruits(
ID int primary key,
ITEMS varchar(50)
);

insert into ddryfruits
values(1,'Dryfruits'),
(2,'Spices')

create table dryfruits(
Did int,
DryfruitsName varchar(50),
Cost int,
Grams varchar (50),
id int foreign key references ddryfruits(id)
);
select * from DRYFRUITS
insert into dryfruits
values (1,'Cashews',199.00,'250g',1),
(2,'Almonds',249.00,'250g',1),
(3,'Raisins',199.00,'250g',1),
(4,'Dates',374.00,'250g',1)

create table spices(
Sid int,
SpicesName varchar(50),
Cost int,
Grams varchar(50),
id int foreign key references ddryfruits(id)
);

insert into SPICES
values (1,'Turmeric powder',24.00,'250g',2),
(2,'Elachi',750.00,'250g',2),
(3,'Mustard seeds',99.00,'250g',2),
(4,'Cloves',312.00,'250g',2)

select * from ddryfruits
select * from DRYFRUITS
select *from SPICES 